package com.demo.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.demo.model.Employee;

public class EmployeeDao {
//    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:orcl";
//    private static final String DB_USER = "c##hr";
//    private static final String DB_PASSWORD = "hr";

    public static Connection getConnection() {
    	Connection con = null;
        try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
        System.out.println("Driver loaded");
        con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl", "c##hr", "hr");
        System.out.println("Connected to the database");
    } catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    catch (SQLException e) {
    		// TODO Auto-generated catch block
    		e.printStackTrace();
    }
        return con;
    }

    public static int addEmployee(Employee employee) {
        int status = 0;
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO employees1 (id, name, department, salary) VALUES (?, ?, ?, ?)");
            ps.setInt(1, employee.getId());
            ps.setString(2, employee.getName());
            ps.setString(3, employee.getDepartment());
            ps.setDouble(4, employee.getSalary());
            status = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public static List<Employee> getAllEmployees() {
        List<Employee> employees = new ArrayList<>();
        try (Connection conn = getConnection()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT id,name,department,salary FROM employees1");
            while (rs.next()) {
                Employee emp = new Employee();
                emp.setId(rs.getInt("id"));
                emp.setName(rs.getString("name"));
                emp.setDepartment(rs.getString("department"));
                emp.setSalary(rs.getDouble("salary"));
                System.out.println(emp);
                employees.add(emp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error in getAllEmployees: " + e.getMessage());
        }
        System.out.println("Number of employees fetched: " + employees.size());
        return employees;
    }

    public static int deleteEmployee(int id) {
        int status = 0;
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM employees1 WHERE id = ?");
            ps.setInt(1, id);
            status = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }

    public static int updateEmployee(Employee employee) {
        int status = 0;
        try (Connection conn = getConnection()) {
            PreparedStatement ps = conn.prepareStatement("UPDATE employees1 SET name = ?, department = ?, salary = ? WHERE id = ?");
            ps.setString(1, employee.getName());
            ps.setString(2, employee.getDepartment());
            ps.setDouble(3, employee.getSalary());
            ps.setInt(4, employee.getId());
            status = ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return status;
    }
}

